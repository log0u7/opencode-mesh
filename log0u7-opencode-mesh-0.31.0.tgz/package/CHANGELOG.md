# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.31.0] - 2026-11-26

### Fixed

- A federated name is never a local box (P1): mailboxByName/listMailboxes
  filter node_id IS NULL — a caller deciding "does this box live here?" can
  no longer answer yes for a foreign row and sink mail into a box no local
  session drains; federatedByName carries the routing row; the sidebar and
  mesh_pools count local boxes only.
- The registry merge is hardened (P2): a BOUND local name (bind_key set) is
  never ceded even when its session went quiet; the per-row validation
  tightens (session_id <= 128, role <= 64, every pool entry must match
  team:<id>); the merge runs in one transaction.
- The reply correlation is server-side (P3): a bare answer (no reply_to)
  auto-carries the pending question's id — lastUnansweredFrom(fromBox,
  toBox, 30 min window), applied on the local, the federated and the peer
  wire paths. The agents' reply discipline is no longer load-bearing (the
  storm root cause dies at the source). Explicit reply_to always wins.
- mesh_wait is hard-capped at 30s and correlates on the sender (P4): the
  matcher returns on the exact reply_to OR any message from the request's
  recipient box arriving after it; the description states the contract
  (only when the next step in THIS turn depends on the answer).

### Changed

- The wake flash loses the reply id (P5): the auto-fill made it redundant —
  ~50 tokens back on every wake of every agent.
- New option debugWake: one plugin.log line per flash (pid, box, fresh
  count, PRAGMA data_version) — the ghost-counter hunt switch (frozen WAL
  snapshot vs orphan instance).

## [0.30.1] - 2026-11-26

### Fixed

- The wake flash carries the oldest pending message id: `mesh: N unread - "subject"
  (reply id: <id>)`. Wake-woken agents could only answer bare (reply_to NULL -
  the flash showed the subject, not the id) and those replies are invisible to
  mesh_wait's reply_to correlation: the waiter starved to its full timeout with
  the reply sitting in its box (reproduced isolated: the reply landed 11s into a
  45s wait, the wait never returned). Root cause of the "orq blocked on wait"
  storm, live since the wake feature.
- mesh_wait's timeout message lists the uncorrelated unread in the box (id,
  sender, subject, reply_to state) instead of a bare timeout line: the caller
  drains and recovers immediately instead of re-waiting blind.
- mesh_wait default timeout 120s -> 60s: every blocked second exposes the turn
  to the host's user-prompt interrupt, and the live fleet test showed every real
  reply lands within ~60s. The long blocking wait has no legitimate use.

## [0.30.0] - 2026-11-25

### Added

- The registry federation: a paired peer pushes its LOCAL mailbox rows at
  rebind (mesh_register/mesh_join) and at pairing completion (POST
  /registry-sync, the pairing auth); the merge is the LWW single-writer per
  name — the ownership conflict resolves on (registered_at, node_id), the
  local names never lose except through a strictly newer registration, the
  inbound registered_at is bounded ([-1h, +5 min skew]) and a LIVE local
  session keeps its name (the two-orq fight resolves: each keeps its own).
  The federated boxes are ADDRESSING-ONLY (never delivery targets, never
  woken, excluded from the pools and the wake stats): a mesh_send to a
  federated name without a peer routes to the owning peer. Each push is the
  sender's full state (the stale federated rows die). The schema v15/v16
  (mailboxes.node_id + registered_at, backfilled).
- The wake resilience: the failed ticks back off exponentially (capped
  5 min) instead of stopping the loop forever; the reminder backoff doubles
  the mute TTL per cycle (10 -> 20 -> 40 -> 80 min cap); a box starved
  through 3 mute cycles alerts the orchestrator mailbox (escalateTo,
  default orq) once per starvation period; the operational warnings land
  in plugin.log beside the store (console.warn is /dev/null under
  serve --service).
- The enrolled-worker surface drops the orchestration tools (mesh_spawn,
  mesh_pair, mesh_worker_*): a worker registers, drains, waits, replies
  and reads the journal — about 4k characters less on every request of
  every worker (the v1 and v2 surfaces).
- mesh_spawn's definition tightened (about 550 characters less per
  request).

### Fixed

- The leaked-transaction recovery: a ROLLBACK that itself fails left the
  transaction open (0.28.2 swallowed the failure silently) — the connection
  read a frozen WAL snapshot forever and the wake loop re-prompted read
  mail (seen live TWICE: the lock held on the mesh.db-shm read-mark byte
  for hours, one real mail re-flashing six times). The connection now
  rebuilds in place on every leaked-transaction surface (the guard, the
  failed rollback, the post-call check) and the warn lands in a real
  plugin log (`plugin.log` beside the store — console.warn is /dev/null
  under `serve --service`). The wake loop probes with a noop transaction
  every tick: a leak is detected and recovered within one poll interval.
- `MeshDb` gains `path` and `reopen()`. The instance lives on — this is
  NOT the rejected conn-level self-heal: it never reopens after an
  explicit close, and it exists to keep this instance honest, not to
  revive a disposed one.

## [0.29.2] - 2026-11-25

### Fixed

- The collapsed mesh sidebar adopts the unified panel grammar (shared
  with the memory panel): compact separators, the labels capitalized and
  pluralized (1 Agent / 14 Agents), unread lowercase and never
  pluralized, no glyphs in fold. The two branches (mail pending / quiet
  inventory) merge into one line: the counters always show, the unread
  segment appears only when it signals.

## [0.29.1] - 2026-11-25

### Added

- The pairing output shows the peer's SPKI fingerprint: `peer fingerprint:
  <sha256-16> (TOFU pinning: check this fingerprint if you're paranoid)`.
  Informative only: the 6-digit code stays the human gesture and the pinned
  Ed25519 proof the trust anchor (no comparison step, no protocol change).

### Fixed

- A DHCP address change on a paired LAN peer left the stored addresses stale:
  the mDNS browser fires `up` once per service and nothing at all on an
  IP-only re-announce, so discovery never refreshed the row and sends kept
  failing (`unreachable` on mesh_send, silently dropped in fanout) until a
  plugin restart. An unreachable send or forward now restarts the browse once:
  the fresh browser hears the peer's next announcement and upserts the current
  addresses.

## [0.29.0] - 2026-11-25

### Changed

- The re-send dedup window widens from 60 s to 6 hours (0.20.0 covered the
  burst retries; the minutes-apart class survived — seen live: three
  identical DMs over twenty minutes, all delivered, reported by the receiver
  as "never received" while they sat unread in its box). The rolling
  recent_mails purge bounds the rows; a genuinely different mail inside the
  window still delivers (the hash covers from + box + subject + body).

- The inbox drain answers compact JSON (the pretty-print cost bytes on
  every drain) and drops `delivery_id` from the agent view — an internal
  key the agent never uses (mesh_wait matches on reply_to). The wire path
  (POST /mail) keeps its shape.

## [0.28.2] - 2026-11-25

### Fixed

- The fatigue mute starved a box forever: three prompts without a drain mute
  the mailbox, and the mute only lifts when the count drops — which requires
  the box to drain, which requires a prompt. Seen live: the orq box held
  eight unread mails (three of them reported by a peer as "never delivered"
  — they were) while the session kept running. The mute now carries a TTL
  (10 min): one reminder per TTL worst case, the mail never starves.
- The inbox protocol rides the standing guidance (the sequential-processing
  failure seen live): drain the whole inbox first, process the set in one
  pass — never act on the first message while the rest sits unread; re-check
  the inbox before any decisive reply; a mesh_wait timeout is not proof of
  loss — re-check before re-sending.
- A connection-level self-heal was prototyped and REJECTED: reopening a
  closed engine revives orphaned plugin instances after a hot-swap — the
  double-wake-loop class behind the 0.24.x phantom. The 0.18.0 contract
  stands: a closed database answers a plain 500 JSON, the orphan dies.

## [0.28.1] - 2026-11-25

### Fixed

- The wake prompt now carries an explicit `messageID` (generated `msg_` +
  uuid per prompt). The transport can retry a `session.prompt` call — the
  server honors an explicit id (`input.id ?? create`), so every retry now
  reconciles to the same message ('existing', no new row) and no ghost turn
  re-fires. Root-caused live: four re-deliveries of one queued prompt,
  spaced 4 s apart (the transport-retry rhythm), each regenerating a fresh
  server-side id because the caller sent none. The vendored SDK generation
  omits `messageID` (stale gen) — the call site casts, the live host
  `SessionPrompt` carries the field.

## [0.28.0] - 2026-11-25

### Fixed

- The phantom-unread class had a second root: a leaked BEGIN pins the WAL
  snapshot forever, and the wake loop then reads a frozen view — re-prompting
  mail the rest of the fleet already read (seen live: one real mail, six
  flashes; `lslocks` showed a READ lock held on the mesh.db-shm read-mark
  byte for hours). Three layers: `withTransaction` now refuses to nest on a
  leaked transaction (loud, not silent), rolls back defensively (a failing
  ROLLBACK no longer eats the original error), and warns if a transaction is
  still open after the call; the connection wrapper exposes
  `inTransaction()` on both engines.

### Added

- The wake collapse gate: at most ONE wake prompt in flight per session
  (the collapse-key pattern). The host queue delivers one queued item per
  idle cycle — a second queued prompt fires later with its count and subject
  already stale. Set at queue time, cleared when the session goes busy (the
  delivered prompt CAUSES the turn, so the busy event is the delivery
  receipt); disengaged when no `sessionRunning` callback exists. Fewer
  phantom turns: the notification cost per event is now bounded at one short
  turn instead of a delivery cycle.

## [0.27.3] - 2026-11-25

### Fixed

- The 0.27.1 tracker keyed on `properties.sessionID`/`properties.status` — a
  shape taken from a stale SDK generation in node_modules. The live wire
  (the host's generated client types) carries everything under `data`:
  `session.status` is `{data: {sessionID, status: {type}}}`, `session.idle`
  is `{data: {sessionID}}`. The tracker therefore matched nothing, the
  mid-turn guard stayed off, and the phantom-unread class relapsed (one real
  mail produced three flashes, the last two with an empty inbox). The
  tracker now reads `data` first (the real wire) and `properties` second
  (older SDK generations).

## [0.27.2] - 2026-11-25

### Removed

- The "opencode-mesh loaded" toast shown at every TUI boot (PO feedback: pure
  noise at each startup; the sidebar already shows the plugin is alive).

## [0.27.1] - 2026-11-25

### Fixed

- The mid-turn guard of the wake loop was silently off: it listened for
  `session.execution.*` events with `data.sessionID`, names and payload the
  opencode v2 bus never emits (the real signal is `session.status` with
  `properties.sessionID` and `status.type` busy/retry/idle, plus
  `session.idle`). The wake loop therefore queued prompts into running
  sessions whose turns drained the mail before the queued prompt fired — the
  phantom-unread class (1-5 flashes per turn with an empty inbox and zero
  pending in the DB, always the same already-read thread; it survived three
  count-freshness fixes because the race was the emission, not the count).
  The tracker now follows the real `session.status`/`session.idle` events and
  keeps the legacy names for older hosts.

## [0.27.0] - 2026-11-25

### Changed

- The spawn default is the natural context of the host: the child runs with
  no directory imposed, locally or on a peer (a session in the host's own
  cwd). The workspace concept remains dropped — the PO rejected the fleet
  workspace — and `project=<dir>` / `worktree: true` stay opt-in.
- A distant spawn signs the projectID only on a project opt-in: the default
  (session) payload is the spec alone — a legacy receiver still verifies it —
  and the 0.24.8 worktree retarget keeps its signed project on its own path.

## [0.26.0] - 2026-11-25

### Added

- Three spawn modes for mesh_spawn — where the child runs is now a choice,
  and the default stops being the worktree:
  - **session** (default): the child runs in the host's natural context — the
    cwd of the peer's serve — with no directory imposed and zero
    dependencies. Nothing touches the worktree table or discovery.
  - **project** (`project=<dir>`): the child runs in that existing directory
    — a real project, git or not (a non-git project is still a project; the
    core opencode conflates the two, the mesh does not inherit that). The
    directory is checked on the target host: locally with a direct existence
    check, remotely inside the signed request, where the peer answers an
    explicit refusal "spawn refused: project directory <dir> does not exist
    on peer".
  - **worktree** (`worktree: true` + `project=<dir>`): the git isolation,
    opt-in by choice — the unchanged 0.24.x machinery (worktree create, the
    0.24.7 discovery refresh retry, the 0.24.8 signed projectID retarget,
    which lives on this path only). `worktree: true` without `project=` is
    refused ("worktree requires project").
- The spawn mode is recorded on the worker row (workers.spawn_mode, schema
  v14; every pre-0.25.0 row is a worktree spawn) so mesh_worker_remove only
  ever removes what the mesh created — a project or session spawn keeps its
  directory, and the worktree API is never called for it.
- Local back-compat: a nameless headless spawn keeps the legacy worktree
  behavior; an enrolled spawn (name=) defaults to session mode. The spawn
  mode travels in the signed distant-spawn spec (project/worktree ride inside
  the signature, the receiver rebuilds them canonically) and the 0.24.5
  one-log-line-per-spawn and 0.24.7 SourceDirectoryNotFoundError paths stay
  dead on the default and project modes (no worktree machinery runs there).

### Removed

- The 0.25.0 fleet-workspace spawn design (`spawnWorkspace` option, the
  `~/projets/fleet` workspace colleague default, `resolveSpawnWorkspace`,
  `WORKSPACE_BRANCH`): superseded by the three spawn modes above — a spawned
  child is now born in the host's natural context by default (session mode),
  not in a shared workspace directory. The 0.25.0 release shipped that
  design; this one replaces it one day later, per the validated redesign.

## [0.24.8] - 2026-11-24

### Fixed

- The headless server's WorktreeTable was never registered (follow-up on the
  0.24.7 live bug): a peer's mesh instance running inside `opencode serve
  --service` binds the serve's OWN project — often `$HOME`, not even a git
  repo — where project resolution registers no source row (only git projects
  get one) and no worktree discovery can ever succeed. The 0.24.7
  refresh-and-retry therefore kept answering "spawn refused: no source
  directory on peer" even after the operator opened a session in the repo
  (that registers the REPO project, not the serve's home project). Distant
  spawn now retargets: the parent signs its own opencode projectID into the
  request (a git project id derives from the git remote, so it names the same
  repo on every host that has it cloned), and the peer creates the child's
  worktree under THAT project — the 0.24.7 discovery refresh then runs against
  the right project and finally registers its source. The retarget is signed
  (a MITM must not swap the birth project), requests without it keep the
  exact legacy signature (old parents verify on new peers), and a peer whose
  opencode never resolved the parent's project answers an explicit refusal:
  "spawn refused: the spawned project is not registered on this peer — open
  the peer's opencode in that project once, then retry". 1.x REST hosts have
  no retarget (their client cannot address another project): unchanged
  behavior.

## [0.24.7] - 2026-11-24

### Fixed

- Distant spawn failed with `Worktree.SourceDirectoryNotFoundError` (seen
  live at the first real `mesh_spawn(node=…)`): the peer's spawn path did not
  resolve a source directory of its own — the host's worktree create requires
  the project's source directory to be a registered row of its worktree
  table, and a headless `opencode serve` peer never runs the worktree
  discovery that registers it (only the desktop app does, when it browses
  workspaces). `createWorkerWorktree` now runs one discovery refresh and
  retries when it sees the tagged error, and a peer with no valid source at
  all answers the explicit refusal "spawn refused: no source directory on
  peer — open the peer's opencode in its project once (worktree discovery
  registers the source)" instead of the bare crash. The new
  `spawnWorktreeBase` option sets the destination base of the worktree of
  each child born from a distant spawn (default: the host's own opencode
  worktree base).

## [0.24.6] - 2026-11-24

### Fixed

- The notify counter read a stale source: the wake flash baked the unread
  count into the queued prompt at emission, and the prompt fires later —
  the displayed number belonged to a past delivery (seen live: 1-5 phantom
  unreads per turn with an empty inbox, mesh_journal silent, and zero
  pending in the DB, always the same already-read thread). The count is now
  recomputed from the DB at every display (`unreadBoxCount`, one cheap
  COUNT per flash): drained since the stat read → nothing is displayed at
  all; the count shown is the database's, always.

## [0.24.5] - 2026-11-24

### Fixed

- The distant spawn handler failed silently between nonce validation and
  worker creation (seen live: nonce consumed, workers table empty, no log, an
  empty error to the parent). The handler now wraps the whole enrolled-spawn
  path: a failure answers 500 with the explicit cause — the real error
  message, never an empty string (an empty-message error normalizes to
  `<name> (no message)`) — and every POST /spawn logs exactly one server
  line with the outcome (ok / refused / failed + cause).
- The client surfaces the peer's error message: the parent's verdict carries
  the peer body's `error` field, and an empty or unreadable body degrades to
  `spawn failed: <status code>` instead of a bare message.
- The worker child resolves to the running opencode binary
  (`process.execPath`) instead of a PATH lookup: a peer launched as a
  service can have a PATH without `opencode`, and the child then died as a
  bare failed row. Bare JS runtimes (dev, tests) keep the PATH fallback.
- The worktree API error envelope no longer treats an empty message string
  as a message: the explicit fallback applies instead.

## [0.24.4] - 2026-11-24

### Changed

- The mesh sidebar starts folded by default. The durable store's initial value
  was already collapsed, but the RPC fallback answered expanded when nothing
  was persisted, and the TUI store adopts that answer right away, so new
  sessions ended up expanded; the RPC default is collapsed now. Sessions with
  a persisted state keep it, and the user's toggle persists on top of the
  initial value as before.

### Fixed

- The collapsed inventory lost a space and the counter tone tiers in the
  0.23.3 rewrite: merging each counter into one muted segment glued `· 7
  pools` to the header and dropped the count's qualifier tone. The counters
  render again as three segments (muted ` · ` separator, count in the
  qualifier tone, label muted), the same grammar as the expanded `⌂` line and
  the memory panel.
- The counters pluralize like the memory panel's `plural` pattern: `1 agent ·
  1 pool · 1 host` instead of `1 agents · 1 pools · 1 hosts`, in the collapsed
  inventory and the expanded fleet line.

## [0.24.3] - 2026-11-24

### Fixed

- Spawn anti-replay nonces are persisted in the mesh db (`spawn_nonces`, schema
  v13, purged on insert): a receiver restart no longer re-opens the 5 min
  replay window for a captured request.
- The distant-spawn spec is validated receiver-side beyond `name`: `role`
  (non-empty, max 64 chars, no control characters) and `pools` (max 8, each
  non-empty and max 64 chars) now get an explicit 403 refusal: both feed the
  child's enroll header, so a newline could inject a fake instruction line.
  The parent's `mesh_spawn` runs the same validation before sending.
- The receiver-canonicalized payload contract is documented in
  `docs/PROTOCOL.md`: extra parent keys and empty pool strings alter the
  rebuilt payload and fail the signature by design; send exactly
  `{task, name, role, pools}`. A test pins the 403.

## [0.24.2] - 2026-11-24

### Fixed

- The collapsed sidebar lost its `▶` toggle: the attention line renders
  `▶ Mesh ● N unread` and the quiet inventory `▶ Mesh · N agents · N pools · N
  hosts` again, exactly as before 0.23.3 (the toggle rides the bold clickable
  `Mesh` segment; the expanded header keeps `▼ Mesh: <name>`).

## [0.23.4] - 2026-11-24

### Changed

- The role leaves the sidebar header: `▼ Mesh: <name>` carries the name only,
  and each hat that declares a role renders its own `≔ <role>` line, one per
  hat (multi-hat sessions stack them), placed after the unread line and before
  the pools. A long role truncates at the last word boundary that fits the
  panel width (default 32), never mid-word; the full role stays in
  `mesh_status`.
- The enrollment guidance asks for short roles: "role: keep it 1-3 words —
  the panel truncates at word boundary; the full role lives in mesh_status".

## [0.24.0] - 2026-11-24

### Added

- **Signed distant spawn**: `mesh_spawn(node=<paired peer>)` births an enrolled
  fleet agent ON that peer. The request travels on the peer's new `POST /spawn`
  endpoint, authenticated by the pairing token AND an Ed25519 signature (the
  parent's node key) over a canonical payload, verified against the PINNED key
  of the requester (no TOFU: an unpinned peer row is refused). Replay defense:
  the request timestamp must sit inside a 5 minute window and its nonce is
  single-use.
- **Deny-by-default reception**: `acceptSpawn` (default `false`) gates the
  endpoint; `spawnQuotaPeer` (default `2`) caps the enrolled workers ONE
  requesting peer may keep running. Refusals are explicit ("spawn refused:
  acceptSpawn disabled", "spawn refused: spawn quota reached (N)").
- **Peer-side lifecycle**: the receiving node executes its own enrolled-spawn
  path (worktree, enrolled child, self-enroll header), stamps the registry row
  with the requesting peer, and acks the parent by DM: `spawned <name> on
  <hostname> (worker <id>)`. The worker lives on the peer's registry; the
  parent does not manage it remotely (v1): the spawned agent posts its own
  `status:` to the pools like any member, and reaping is the peer's job
  (`mesh_worker_stop` there).

## [0.23.3] - 2026-11-24

### Changed

- **Collapsed sidebar shows one conditional line**: the attention state when
  mail is pending (`Mesh ● N unread`), the inventory only when quiet
  (`Mesh · N agents · N pools · N hosts`) - never both stacked. The `Mesh`
  label is bold (entity tone), the counters muted (value tone), and the `▶`
  glyph drops: the header row stays clickable. README panel legend follows.

## [0.23.2] - 2026-11-24

### Fixed

- **Expanded header separator is a colon**: `▼ Mesh — <name> (<role>)` became
  `▼ Mesh: <name> (<role>)` — the em dash wasted width for nothing (the global
  no-em-dash rule applies to the panel too). The `no mailbox` segment line and
  the README panel example/legend follow.

### Docs

- **Stale `☰` references swapped for `≡`** in the `icons` docstring
  (`src/options.ts`, ships in `dist/options.d.ts` inside the tarball) and
  `docs/CONFIGURATION.md` — the glyph was renamed in 0.23.1.

## [0.23.1] - 2026-11-24

### Fixed

- **Sidebar pools glyph swapped for a narrow one**: the `☰` glyph (U+2624,
  East-Asian Ambiguous) is drawn double-cell by the terminal, which glued the
  next character on the panel (seen live by the PO). It is now `≡`
  (U+2261, Neutral narrow, guaranteed single-cell); the double trailing space
  of 0.22.1 is kept.

## [0.23.0] - 2026-11-24

### Added

- **Enrolled spawn — `mesh_spawn(task, name, role, pools)` births a fleet
  agent**: a worker spawned with a `name` runs with
  `OPENCODE_MESH_CHILD=enrolled` instead of `=1` — it skips the mesh server and
  mDNS exactly like a headless worker (the host's server serves every session
  of the host), but keeps ALL the mesh tools (they act on the shared host
  database), self-enrolls at its first turn through its prompt header
  (`mesh_register`/`mesh_join`, no new protocol; `pools[0]` becomes the primary
  group, with a documented fallback when the pool is brand new) and reports
  status like any agent. Without `name`, the spawn is unchanged (plain headless
  worker, back-compat). The registry row carries the mailbox name (schema v11);
  a name collision hands the mailbox over — last binder wins.
- **`spawnMax` quota** (option, default `4`): `mesh_spawn` refuses an enrolled
  spawn past the limit ("spawn limit N reached, reap one first"); only RUNNING
  enrolled workers count, plain headless workers are unlimited.
- **Reap leaves the pools**: a deliberate `mesh_worker_stop`/`mesh_worker_remove`
  of an enrolled worker makes the reaper leave its pool memberships; the
  mailbox row itself survives and re-binds on the next `mesh_register` of the
  same name (the reaper skips the leave when the box was already handed over to
  another session). A child that dies brutally is NOT reaped: its pools stay
  until a future mailbox GC handles the leftovers.

## [0.22.1] - 2026-11-24

### Fixed

- **Sidebar pools filtered to the asking session's pools**: the expanded panel
  listed every pool on the host (seen live: 7 pools for a session member of a
  single one). The `☰` section now lists only the pools containing at least
  one of the asking session's hats (the `pools.memberNames` × session hats
  intersection); sorting (unread desc, then alpha), the cap of six rows and
  the `☰ … +N more` overflow are unchanged, and other sessions' pools never
  appear.
- **Glyph spacing doubled**: the panel glyphs (☰ ⌂ ⇄, and the `…` of the
  overflow lines) are ambiguous-width: a terminal that draws them double-cell
  glued the next character (seen live as a parasite after `☰`). Each glyph
  segment now carries two trailing spaces: the first absorbs the extra cell
  when the glyph is drawn wide, the second stays as the visible gap.
- **`icons` option** (`boolean`, default `true`): `false` swaps the glyphs for
  lowercase dim text labels (`pools`, `fleet`, `peers`) while names and
  counters stay: the fallback for terminals that handle ambiguous-width
  glyphs badly.

## [0.22.0] - 2026-11-24

### Changed

- **TUI sidebar v4 — quota-style 3-tier emphasis** (design frozen with the PO,
  same grammar as memory 0.20.4): every line is a list of tone segments the
  renderer maps to the theme (entity = text + bold, qualifier = text, value =
  textMuted, alert = the theme's attention color), theme-aware,
  `wrapMode="none"` everywhere (hard truncation), icon set ● ☰ ⌂ ⇄, zero blank
  lines (an inapplicable line is omitted). Expanded: the hats line is replaced
  by identity in the header — `▼ Mesh — name (role)` from the session's first
  hat, extra hats as muted `also name (role)` lines; one unread line (omitted
  at 0, alert-colored glyph); pools one per line as `☰ pool (members)`, sorted
  by the session's unread in them (descending, then alpha), capped at six rows
  plus `☰ … +N more`; one counters line `⌂ agents · pools · hosts`; peers last,
  one per line `⇄ host`, same cap. Locks and per-member presence left the
  panel (PO decision). Collapsed keeps one line with the four counters
  (`Mesh ● N unread · N agents · N pools · N hosts`) in the same tone grammar.
  The formatter returns `SidebarSegment[]`, pinned by tests; the host renderer
  applies the tones.

## [0.21.0] - 2026-11-24

### Added

- **Host capabilities** — `mesh_status` carries a `capa` snapshot: cpu cores +
  1-minute load average, RAM total/used, GPU VRAM (model + total/used MB) when
  `nvidia-smi` answers on the machine, workers in flight (`mesh_workers`
  `running` rows) and sessions mid-turn (the plugin's `session.execution.*`
  tracking). One 60 s cache shared by every reader — `mesh_status`, the
  `/status` endpoint and the TUI RPC snapshot — so a poll never doubles the
  probes; a CPU-only machine (or a missing/timeouted `nvidia-smi`) simply
  leaves the `gpu` field out, like the address providers do.
- **`GET /metrics`** — Prometheus text format (`text/plain; version=1.0.0`),
  the lingua franca VictoriaMetrics ingests natively:
  `opencode_mesh_cpu_load_avg`, `opencode_mesh_ram_used_mb`,
  `opencode_mesh_ram_total_mb`, `opencode_mesh_gpu_vram_used_mb` (when the
  capa snapshot carries a GPU), `opencode_mesh_workers_in_flight`,
  `opencode_mesh_sessions_running`, `opencode_mesh_messages_total`,
  `opencode_mesh_deliveries_unread`. Same bearer-token auth as `/status`
  (Prometheus sends the `Authorization` header natively); the scrape reads the
  same shared capa cache, zero extra subprocesses.

### Fixed

- **Wake tick reads the database in one statement** — the tick used to run
  two SQLite queries per mailbox (unread count + wake gate) plus one more at
  prompt time (preview subject): N boxes cost 3N reads every 5 s. The three
  per-box reads are regrouped into one grouped query (`wakeBoxStats`, JOIN +
  CASE + correlated subject subselect) with identical gating semantics
  (deliberate `wake` flag, direct-mail origin check, oldest-subject preview).

### Changed

- **Tool description diet (−28 %)** — every tool and argument description in
  the shared v1/v2 spec compressed (3636 → 2623 chars); the contracts stay:
  pairing flows, wake semantics, defaults, formats, error behaviors are all
  still stated. Descriptions must not lie: nothing was dropped that the code
  does not honor.

## [0.20.0] - 2026-11-24

### Added

- **Content dedup at delivery** — the same mail from the same sender to the
  same box delivered twice within 60 s is a no-op: the second delivery
  returns the existing message id instead of writing a second row. The
  duplicate-delivery defense for sender-side re-sends (bug 3 sysops, seen
  live: one DM delivered twice, 14 s apart, two message ids, after the sender
  re-executed its sends following a local crash). The key carries the full
  content — sender node, sending box, target box, subject, body, reply_to —
  so a broadcast never swallows the same text to another box, and `reply_to`
  stays in the key so identical replies to different messages remain
  distinct. The 60 s window keeps legitimate repeats passing: daily
  reminders with identical content land hours apart.

## [0.19.0] - 2026-11-23

### Changed

- **`mesh_register(primary=X)` auto-joins X** — one natural enrollment call
  instead of register-then-join-then-reregister: a declared primary the box
  has not joined yet is joined at registration (pool membership was previously
  left untouched, so the box declared a primary it was not a member of). A
  nonexistent pool is still refused. Re-registering without `primary` still
  keeps the declared one.

## [0.18.1] - 2026-11-23

### Fixed

- **CI `Typecheck tests` green again** — the 37 pre-existing test typing
  errors fixed (required `self` on `startMeshServer` test fixtures, the
  `execFile` callback's missing `stderr` parameter, `exactOptionalPropertyTypes`-
  clean peer fixtures, `SidebarRpc.bind` / `MeshContext.bindKey` in mocks,
  `DeliverResult` narrowing, dead fields dropped from legacy-mail tests).
- **Coverage gate green again** — fixing the typecheck step unmasked a latent
  branch-coverage shortfall (79.3% < 80): the option-validation branches for
  `wake`, `tls`, `insecureHttp`, `memorySync`, `memorySyncInterval`, `mailbox`
  and `mailboxRole` were never exercised; new `parseOptions` validation tests
  bring branches to 80.7%. Test-only: no runtime behavior change. The
  `[0.14.2]` section, lost with the peer-fix commit, is restored below.

## [0.18.0] - 2026-11-23

### Fixed

- **Multi-hop fanout worked only up to 2 nodes**: the relay forwarded a
  broadcast with the ORIGIN node's id in the mail `from`, while the next hop
  binds the bearer token and the pairing proof to the node on the wire and
  401'd any mismatch. On a mesh of 3+ nodes (A→B→C) the mail died at the
  relay: C never saw it. The relay now signs every hop with its OWN identity
  (the wire `from` is always the node putting the mail on the wire); the
  origin stays traceable through `origin_id` + `from_box`, both stored. The
  origin_id dedup keeps a direct re-delivery of the same broadcast a no-op.
  Covered by a new 3-node e2e (origin → relay → final over real HTTP
  servers, plus the direct-leg dedup).
- **TLS peer without a pinned key = send refused, never silent TOFU**: a
  legacy pairing (pre-pinned-keys) with `tls = 1` yielded `pk = null` and the
  TLS transport accepted ANY certificate — a MITM could steal the bearer
  token. `mesh_send` now refuses with `error: peer <id> is TLS but has no
  pinned key — re-pair with mesh_pair`, and the fanout skips such peers.
  TOFU stays a pairing-code-only capability (first contact, the code is the
  capability).
- **Wake guards**: a prompt slower than the poll interval can no longer run
  two ticks concurrently (in-flight guard, no double prompt), and a stop()
  during an in-flight tick prompts no further box after dispose (re-check
  after the prompt await).
- **Handler exceptions answer 500 JSON**: an uncaught throw in any route is
  caught by the server handler and answered `{"error": "internal error"}`
  (500) — never an unhandled rejection, which would crash the host process.
- **Response reads bounded**: the client transports cap response bodies at
  2 MiB (plain fetch reader and TLS stream: over the limit the read is
  cancelled and the send maps to a plain error) — a hostile peer cannot
  balloon host memory.

### Changed

- `POST /mail` and `/memory-sync` bodies resolve `too_large` as soon as the
  limit is crossed (buffering stops; the HTTP layer tears the connection down
  with the 413). The pair-code rate limiter is LRU-bounded at 1000 remotes.
  Address-provider subprocesses are killed with SIGKILL on timeout.

## [0.17.0] - 2026-11-23

### Added

- **`mesh_send` gains `wake: true`** (Slack model, acté PO): a deliberate pool
  broadcast can wake every member, local and cross-host. The flag rides the
  whole mail path (`POST /mail` body, fanout forwarding, `messages.wake`
  storage, schema v9). Default stays quiet: a pool post without the flag
  wakes nobody, whether it is fanouted (origin_id differs from the local id)
  or a multi-recipient local broadcast; the sender flags the mention when the
  message must be seen now. Direct mail (one recipient) always wakes, flag
  unnecessary. `wakePools` keeps its operator-wide override meaning.
- **Addressing guidance** (third DM-vs-pool incident today): the standing
  directive now carries the rule — team-wide announcements go to the POOL as
  one post (fanout is silent, nobody wakes), never as individual DMs (a DM
  wakes its recipient); DM = only what must be seen NOW by ONE mailbox.

## [0.16.1] - 2026-11-23

### Fixed

- **Transactional inbox fetch+ack**: `mesh_inbox` (and the `mesh_wait` reply
  path) used to fetch the unread rows and mark them read in two separate,
  non-transactional write phases. A process killed in between (which happens
  on plugin hot-swap) left deliveries marked `read` but never served, and the
  agent saw "inbox empty" over a real mail (seen live on ricinus during a
  0.10.10 → 0.14.2 swap). Fetch and read-marking now run in one SQLite
  transaction (`inboxRead` / `waitReplyRead` in `src/lib/mail.ts`): either the
  rows are served and marked read together, or nothing happens. The residual
  window (the process dying after the transaction commits but before the
  response reaches the model over RPC) is documented in the code and inherent
  to RPC over a dying process; it is now microseconds-wide instead of the
  whole fetch→ack→return span. No re-delivery on boot, on purpose:
  re-marking recent reads as unread would re-serve duplicates after every
  normal restart.

## [0.16.0] - 2026-11-23

### Changed

- **Pool mail no longer wakes sessions — DMs only** (token economy, acté PO):
  the wake loop skips a mailbox whose pending mail is ALL fanouted
  (`origin_id` differs from the local message id — the same `forwarded`
  semantics `mesh_journal` uses). Pool broadcasts are read on natural turns
  or via `mesh_journal`; a direct DM landing among unread pool mail still
  wakes, with one prompt draining everything. Opt back in with
  `wakePools: true` (new option, default `false`).
- **Compact wake notification**: the injected prompt went from a full
  sentence to `mesh: <n> unread — "<first pending subject>"`, the subject
  truncated to 60 chars. The message stays self-carrier: agents read
  `mesh_inbox` from their standing guidance.
- **Ack-silently guidance**: the standing directive gains the rule — a DM
  that only confirms receipt needs no reply, the sender's delivery receipt
  is the ack; reply only when asked or when adding information (extends the
  0.14.1 anti-narration line).

## [0.15.0] - 2026-11-23

### Added

- **Modular address providers** — the advertised candidate IPs of this machine
  (`mesh_status` `tailnet_addresses`) now come from a small provider mold
  (`lib/providers.ts`): one provider = one function rendering this machine's
  IPs, shared-cache semantics borrowed from the tailscale pattern (60 s TTL,
  2 s subprocess timeout, absent CLI or error = empty list, never a failure).
  Native overlays: **tailscale** (already there, including Headscale via the
  same CLI), **netbird** (`netbird status --json`, top-level `netbirdIp`),
  **zerotier** (`zerotier-cli listnetworks`, assigned-IP column). Tunnels
  without a CLI — WireGuard, IPsec, any SSL VPN — are covered by static
  `addresses` in the plugin options. Providers can be toggled per name with
  `providers` (default: all enabled; a missing CLI costs nothing). The
  tailscale extraction keeps its exported names from `lib/discovery.ts`, and
  new overlays land as one function + one array entry, by PR — no runtime
  plugin system.

## [0.14.2] - 2026-11-23

### Fixed

- 0.14.1 pinned the @opentui peers to `>= 0.9.4`, making the package
  uninstallable on hosts resolving opentui lower; the host owns the opentui
  version — permissive peers (`>= 0.5.0`) restored.

## [0.14.1] - 2026-11-23

### Fixed

- **Wake decoupled from the TUI** — since opencode 2.4.0 the TUI plugin slot
  requires `@opentui >= 0.9.4`, and a host that cannot load it stopped the
  tab-render bind, leaving the in-memory `sessionsSeen` empty: `sessionKnown`
  was false everywhere, the wake loop skipped every mailbox and an idle
  session never re-registered on its own — only a human click unblocked it.
  `sessionKnown` now consults the host's **live session list** (setup
  `ctx.session.list`, paginated, cursor-chained, archived sessions excluded —
  `lib/sessions.ts`); `sessionsSeen` (mesh tool calls + TUI bind) stays as a
  complement. Hosts without the list fall back to the previous behavior, with
  a one-time warning.
- **Notification ghosts** — post-hot-swap "N unread" counts came from an
  orphaned previous instance (its timers kept running against a closed
  state). The unread count is read fresh from the same process' database
  right before each prompt, plugin dispose now stops every timer
  (wake loop, session lister, sync pusher, workers) and is idempotent, and a
  wake tick that fails 5 times in a row stops the loop with a logged reason
  (end of the silent catch).
- `@opentui/core`/`@opentui/solid` peer requirement raised to `>= 0.9.4`
  (matches opencode 2.4.0), dev `@opencode/plugin` bumped to 2.3.2 (the
  version exposing the paginated session list to the setup context).

### Added

- **Anti-narration guidance**: every session's system prompt carries the
  standing directive injected through the v2 session context hook — status
  only on significant state changes (release, block/unblock, decision,
  failure); `mesh_journal` answers "what happened" on demand.

## [0.14.0] - 2026-11-23

### Added

- **mesh_journal** — read-only traffic journal, the anti-narration record: the
  mesh database already stores every mail (sender, recipients, subject, time,
  delivery), the new tool is a query over it, with no new writes and no new
  tables. Agents consult the journal on demand instead of narrating routine
  operations to the human. Filters: `since` (ISO or epoch ms), `mailbox`
  (sender or recipient), `pool` (broadcasts only), `limit` (default 50, max
  200), newest first. Metadata only — bodies stay readable through
  `mesh_inbox`. Cross-host arrivals (origin id minted by a remote node) are
  flagged `forwarded`.

## [0.13.0] - 2026-11-23

### Added

- **Primary group**: every mailbox can declare one primary group at enrollment
  (`mesh_register(primary="team:x")`, validated against the pools that exist on
  the node). The declaration is stored on the mailbox (`mailboxes.primary_pool`,
  schema v8), reported by `mesh_status` (`primary=<pool>`) and carried in the
  sidebar snapshot (`primary_pool`) for the panel to display. Usage convention:
  the lead of the primary group receives the mailbox's enrollment confirmation,
  falling back to the orchestrator; the human can dictate the primary at
  enrollment. Declarative only — mail routing is unchanged.

### Changed

- **Collapsed sidebar header renders two lines**: the toggle line carries the
  unread marker only (`▶ Mesh ● N unread`, nothing else on that line), the
  counts move to their own line (`N agents · N pools · N hôte(s)`). Expanded
  format is unchanged; with no snapshot the collapsed header is the bare
  toggle line.

## [0.12.0] - 2026-11-23

### Added

- **Cross-host memory sync (`/memory-sync`)**: the mesh now transports the shareable
  memory of opencode-memory 0.19+ between paired hosts. The two plugins stay fully
  decoupled — the filesystem is the only contract, and the mesh never parses the
  payload:
  - `POST /memory-sync` (auth: the mail machinery, token + `x-mesh-from`/`x-mesh-proof`
    headers) stores the peer's JSONL verbatim under
    `<dataDir>/memory-sync/inbox/<node id>.jsonl` (atomic tmp + rename, 0600) and
    answers `{accepted: <bytes>}`. A pending pairing token can bind on the first
    accepted push (proof attested against the pinned key), like the first mail does;
    bodies up to 1 MiB (the outbox is a snapshot, mail's 64 KiB limit stays).
  - **Outbound push loop**: every `memorySyncInterval` minutes (default 15, 0 = off;
    `memorySync: false` gates the loop entirely — reception is always on) the plugin
    pushes `<dataDir>/memory-sync/outbox/shareable.jsonl` (written by the memory
    plugin's `memory_export`) to every paired peer over its pinned TLS connection.
    The stamp advances only when every peer accepted, so a peer that was down catches
    up on the next cycle; duplicates are free (the importing side is idempotent per
    entry id).
  - **Import** is the memory plugin's job: its housekeeping sweep imports the inbox
    files and renames them `.imported` (opencode-memory 0.19.0, same path convention).
- Node ids are validated as inbox filenames (`[A-Za-z0-9._-]{1,64}`) before any
  filesystem write; a peer row with a hostile id answers 500 instead of writing.

## [0.11.0] - 2026-11-23

### Changed

- **BREAKING — TLS on all mesh traffic**: the mesh server speaks HTTPS on its
  port (default 4399) and every client call (`sendMail`, `getPools`,
  `postPairCode`) upgrades to TLS when the target does. Peers on 0.10.x can no
  longer send to a 0.11+ node until both hosts upgrade (assumed: mesh hosts on
  a team upgrade together). A documented escape hatch exists: plugin option
  `"insecureHttp": true` opens an extra plain-HTTP listener on port+1, and
  `"tls": false` turns TLS off entirely — both default off.
- **Certificates derive from the node identity**: the Ed25519 key that already
  signs pairing proofs mints the node's self-signed X.509 certificate (a
  minimal RFC 5280 DER encoder in `src/lib/tls.ts`; node:crypto does the
  signing). Zero new trust: the certificate presents the exact key peers
  already pin.
- **Certificate key pinning**: clients verify the peer's certificate SPKI
  against the pinned pairing key during the handshake; a mismatched
  certificate is rejected before any response body is read. Unpinned peers
  (legacy manual pairings) fall back to TOFU semantics.
- **TOFU on code pairing**: the first `POST /pair-code` over TLS accepts the
  peer's self-signed certificate without a pin, then pins the certificate key,
  which must equal the counter-offer's public key (the node key). Subsequent
  connections to that peer are pinned.
- New pairings and discovered 0.11+ peers (mDNS TXT `tls=1`, offer blobs
  `tls: true`) store `tls = 1` in the peers table (schema v7, guarded
  `ALTER TABLE`); `mesh_send` and fanout choose `https` + pin per peer.
- `mesh_pair(code=…, address=…)` addresses an assumed-TLS peer; legacy peers
  discovered over mDNS without the `tls` flag keep plain HTTP.

### Added

- Plugin options `tls` (default `true`) and `insecureHttp` (default `false`).
- `src/lib/tls.ts`: `nodeTlsMaterial(dataDir)` (identity-derived key + cert,
  cached per process), `buildTlsMaterial(identity)`, `certPkSpki(certPem)`.

## [0.10.11] - 2026-11-23

### Fixed

- **Per-tab panel**: the snapshot now exposes the asking session's hats —
  every mailbox bound to that session, each with its own unread count —
  instead of a single `me` mailbox. A multi-hat session (one tab owning
  several agent boxes) sees all of its boxes; the collapsed sidebar shows
  their total unread.

### Changed

- The collapsed header shows the full counters line — unread · agents ·
  pools · hosts — reusing the sidebar summary instead of building a subset.
- Hosts = 1 (this node) + paired peers: a lone node reads "1 hôte", one
  paired peer "2 hôtes".

## [0.10.8] - 2026-11-23

### Fixed

- Wake prompts no longer quote an unread count: a queued prompt can fire
  after the session acked some mail, and a stale number reads as a false
  positive (observed live on a multi-hat session). The prompt now says
  "unread mail waiting" — the signal is the wake itself, mesh_inbox is the
  truth.

### Fixed

- **Bind no-steal**: the TUI mount bind re-bound ALL stamped boxes to the
  currently rendered tab's session on EVERY tab switch — hats churned across
  tabs as the user switched (the "agents drop pools / exchange roles"
  reports). The bind now only recovers boxes whose bound session has NOT
  been seen in this process (dead pre-restart ids); a box bound to a live
  tab's session is never stolen. Restart recovery keeps working.
- Includes 0.10.7-diagnostic: `mesh_status` reports the calling session id.

### Fixed

- **The v2 adapter never passed the fanout to the tools** (lost in a 0.9.4
  merge): every tool-originated broadcast with no local recipients errored
  instead of forwarding — pool federation silently died for `mesh_send`
  broadcasts (the relay path from remote arrivals still worked). The fanout
  is wired again, with a regression test asserting the forward over HTTP.

## [0.10.5] - 2026-11-22

### Fixed

- `mesh_join` / `mesh_leave` / `mesh_send` default to the **most recently
  touched box** of the session (multi-box: the default was the first box by
  creation date — the oldest — so enrollment joins landed on the wrong
  mailbox). Explicit `box=` override available.
- `SCHEMA_VERSION` bumped to 6: the 0.10.3 mailboxes rebuild (drop
  `UNIQUE(session_id)`) never ran on existing v5 stores.

## [0.10.4] - 2026-11-22

### Fixed

- The 0.10.3 mailboxes rebuild (drop `UNIQUE(session_id)`) was dead code on
  existing databases: `SCHEMA_VERSION` was not bumped, so v5 stores skipped
  the migration entirely and multi-box stayed broken on every pre-0.10.3
  database. Version bumped to 6 — the rebuild now runs on open. New databases
  were unaffected (fresh schema already correct).

### Fixed

- **Multi-box sessions**: one TUI wearing several agent hats used to drop the
  previous mailbox at every new enrollment (one-box-per-session rule) — pools
  and roles churned as roles rotated. A session now owns SEVERAL mailboxes:
  `mesh_register` never deletes another box, `mesh_inbox` aggregates all the
  session's boxes (each row labeled with its box), the wake loop aggregates
  per session (one prompt listing the boxes), and `mesh_send` gains an
  optional `box=` to choose the sending mailbox.
- **Sidebar per session**: switching tabs now shows THAT session's state
  instantly (snapshots cached per session id instead of one shared "latest").

### Changed

- Schema v6: `mailboxes` loses `UNIQUE(session_id)` (rebuild migration).

## [0.10.2] - 2026-11-22

### Added

- Code pairing: `mesh_pair()` now emits a **6-digit code** (30 min) instead of
  a raw token blob. The peer runs `mesh_pair(code="482913")` — on the same LAN
  the address is autodiscovered (mDNS), cross-subnet adds `address=`
  (`host:port`). The code endpoint exchanges both offers in one call: the peer
  binds you AND mints a counter-offer you bind automatically — **one command
  each side, both paired**.
- The code is a capability, not a secret: trust stays anchored on the Ed25519
  proof (pk pinned at completion). `POST /pair-code` (unauthenticated
  bootstrap) is rate-limited per source (5 consumed attempts / 5 min).
- Offers now carry the emitter's hostname: paired peers display their real
  name instead of the `manual` placeholder; the sidebar labels legacy manual
  pairings as `id@address`.
- Blob offers (`mesh_pair(offer="MESH1-...")`) kept for agent-to-agent flows
  (files, DMs); legacy node_id/token completion still accepted for older
  mesh versions. Offer TTL raised 5 min → 30 min.

## [0.10.1] - 2026-11-22

### Fixed

- Wrong-mailbox wake attribution after a restart. Session records outlive
  their process: `ctx.session.get` called a dead pre-restart session "alive",
  so the host-wide loop prompted it with mail that belonged to other
  mailboxes (6admin pinged forever over quartermaster's unread delivery,
  while its own `mesh_inbox` read empty — the box was bound to the dead
  session id). The wake loop now only trusts sessions this instance has
  actually SEEN since boot (a mesh tool call or a TUI bind); an unseen
  session's mailbox waits for the agent's first turn, which re-registers and
  re-binds the box per the AGENTS.md check-in convention.

## [0.10.0] - 2026-11-22

### Added

- Pool federation across paired hosts. A broadcast (`to: "team:<pool>"` or
  `to: "all"`) that produced local deliveries is forwarded to the paired peers
  that also hold members of that pool (discovered over a new authenticated
  `GET /pools` endpoint, cached 60 s), where the host-wide wake loop (0.9.3)
  prompts the local members. Boîtes and wake stay local per host — only mail
  travels.

### Fixed

- `mesh_send(peer=<own node id>)` — same-machine sessions share one node —
  used to fall into the global feed unread. It now routes as a local delivery
  when `to` is given, and errors with guidance otherwise.
- A pool broadcast whose only member is the sender (empty local recipients)
  no longer errors when federation can carry it: the origin id is synthesized
  and the mail is forwarded to the remote members.
- Forwarded mail now carries the pairing proof: first contact after a fresh
  pairing (peer token not yet bound on our side) would 401 before the drive-by
  binding had a chance to fire.

### Security

- Broadcast fanout is loop- and duplicate-safe: the wire gains `via`
  (node ids already traversed — a relay never forwards to a listed peer) and
  `origin_id` (a receiver that already stored the broadcast turns the second
  arrival into a no-op).
- New authenticated route `GET /pools` returns the node's local pool map.
- Schema v5: `messages.origin_id`, migrated in place.

## [0.9.4] - 2026-11-22

### Fixed

- No more stale wake prompts for mid-turn sessions. The prompt was queued
  (`delivery: "queue"`) with the unread count baked in at creation time: a
  session running a long turn acked the mail during the turn, then received
  the queued prompt claiming unread messages that were already read (the
  orchestrator's recurring "false positives"). The plugin now tracks running
  sessions from the host's durable execution events
  (`session.execution.started/succeeded/failed/interrupted`) and the wake loop
  skips them — their turn-start check-in reads the box anyway. Prompts fire
  only for idle sessions, so the count is fresh at delivery. When the event
  stream is unavailable, the loop falls back to the previous behavior.

## [0.9.3] - 2026-11-22

### Fixed

- Wake is now host-wide. One opencode process — notably `opencode serve` —
  hosts many sessions, but the wake loop tracked a single "current" session id
  (last mesh tool call), so only that session's mailbox was polled: mail piling
  up in other live mailboxes never woke their agents. The loop now iterates
  every registered mailbox, checks the session lives on this host
  (`ctx.session.get`), and prompts that session — headless sessions included.
  Per-mailbox cooldown, foreign-host and dead-session skips.

## [0.9.2] - 2026-11-22

### Fixed

- Wake reliability: the wake loop only knew the session's id after the first
  mesh tool call, so a freshly restarted (or long-idle) session never woke on
  incoming mail, and a mailbox stayed bound to the dead pre-restart session id.
  Two coexisting binding paths fix it:
  - **Dynamic**: `mesh_register` stamps the mailbox with an instance binding
    key (project id + directory), and the TUI `bind` RPC re-binds every
    stamped box to the live session at mount — restarts and handoffs need no
    configuration and no re-registration.
  - **Static (optional)**: `mailbox` / `mailboxRole` plugin options re-bind
    their box at every mount; on a name collision the last act wins.
  Verified against the host source: `Session.prompt` wakes an idle session
  (`packages/core/src/session/session.ts`, `execution.wake`), so a bound idle
  session reacts to incoming mail within one poll interval.

### Added

- `docs/ORGANIZATION.md`: four multi-team reference models (flat teams with
  bridges, a centralized `tower` orchestrator, a manager hierarchy, ad-hoc
  squads) with mermaid diagrams and the pools-are-announcements convention.
- `wakeIntervalMs` option (default 5000) to tune the wake poll interval.

### Changed

- Schema v4: `mailboxes.bind_key` (instance binding), migrated in place.

## [0.9.0] - 2026-11-22

### Added

- Sidebar v2 (quota-style): collapsible header with toggle (click or
  `mesh.toggleSidebar`), collapsed by default showing `N unread · M agents ·
  K pools`; expanded shows my mailbox with unread count, one line per pool
  with per-member presence (`●` fresh < 2 min, `○` warm < 15 min), peers and
  locks. The snapshot RPC takes an optional `sessionID` (from the
  `sidebar.content` slot input) and resolves the asking session's mailbox,
  per-mailbox presence ages and the pool membership map.

## [0.8.1] - 2026-11-22

### Fixed

- Sidebar collapse state survives TUI restarts even for scoped plugin ids
  (`@scope/name`): the host's storage segment validation rejects them
  (anomalyco/opencode#62634, fix pending in PR #62638), so the collapse state
  is now persisted by the setup side through the raw storage domain under an
  escaped key (`plugin.<escaped-id>.mesh-sidebar`) and synced to the TUI over
  RPC. In-memory remains the last resort on hosts without RPC.

## [0.8.0] - 2026-11-22

### Added

- Named mailboxes: `mesh_register(name, role?)` binds a session to a mailbox;
  `mesh_send(to=...)` routes locally by mailbox name; `mesh_inbox` reads only
  the caller's box. Ends the shared-inbox cross-drain where the first session
  to run consumed every message on the node.
- Pool broadcast: `mesh_join` / `mesh_leave` / `mesh_pools` manage persisted
  pool membership; `mesh_send(to="team:<pool>")` delivers one copy per member
  (sender excluded), `to="all"` reaches every registered mailbox. Per-member
  delivery rows mean each recipient acks independently.
- Request/response: `mesh_wait(id, timeout)` blocks the agent turn until a
  message with `reply_to: <id>` lands, then returns it acked.
- Wake (OpenCode 2.x): the plugin watches the session's mailbox (5s poll,
  60s cooldown) and injects a prompt via `ctx.session.prompt` when unread mail
  arrives, so an idle agent reacts to incoming mail. Disable with `wake: false`.
- Presence: mailboxes carry role, pools and `last_seen`; `mesh_status` shows
  the age of every registered box.
- Remote mailbox addressing: `POST /mail` accepts optional `to`, `from_box`,
  `reply_to`; an unknown `to` falls back to the node's global inbox (old
  receivers simply ignore the fields).
- Retention: messages older than 7 days are swept at server boot.
- Schema v3: `mailboxes`, `deliveries` tables; `messages.from_box` /
  `messages.reply_to`; migration from v2 in place.

### Fixed

- `mesh_send`/`mesh_inbox` tolerate a missing session context (tests, exotic
  hosts) instead of failing on a SQLite bind with `undefined`.

## [0.7.1] - 2026-11-07

### Fixed

- The TUI no longer crashes on hosts whose storage layer rejects scoped npm
  plugin ids (`TypeError: Invalid storage segment`, anomalyco/opencode#62634).
  The sidebar falls back to in-memory collapse state: functional, but not
  persisted across TUI restarts until the host-side fix lands.

## [0.7.0] - 2026-11-06

### Added

- Themed mesh sidebar: bold header and muted peer lines using the active
  theme's text colors.
- Sidebar collapse: the `/mesh` toggle keybind persists its state in durable
  storage, so the collapsed sidebar survives TUI restarts.
- Event refresh: the sidebar refreshes immediately (debounced) on server
  events, with the 15s polling as fallback.
- `/mesh` now opens a dialog with the full snapshot instead of a toast.

## [0.6.0] - 2026-11-06

### Added

- Live mesh sidebar: the TUI part polls a `mesh.snapshot` RPC (registered
  server-side) every 15s and renders the node, one line per paired peer and
  the active lock count. Hidden on v1 hosts and while the server is down.

## [0.5.1] - 2026-11-06

### Fixed

- Peer dependencies aligned with the dual-export pattern: `@opencode-ai/plugin`
  pinned to `^1.18.32` and `@opencode/plugin` to `^2.0.26`, both optional.
  The previous `>=2.0.0` range blocked installation because no matching
  version exists on npm.

## [0.5.0] - 2026-11-05

### Added

- TUI plugin (phase 0+1): toast, `/mesh` slash command, sidebar slot.

## [0.4.1] - 2026-10-24

### Fixed

- The package loads under OpenCode 2 again. The v1 implementation imports
  `@opencode-ai/plugin`, which only v1 hosts resolve, and it sat in the static
  import graph, so v2 hosts rejected the whole plugin at load time
  (`Cannot find package '@opencode-ai/plugin'`). The v1 entry is now loaded
  lazily from `server()`: a v2 host never calls `server()` and therefore never
  resolves the v1-only packages. The named `MeshPlugin` export is type-only.
- The v1 worktree REST factory moved from `lib/worktree.ts` into `plugin.ts`
  for the same reason: it imports `@opencode-ai/sdk/v2`, which must stay out
  of the static import graph too. Shared option plumbing moved to
  `options.ts`, imported by both adapters.
- `smoke:dist` now audits the static import graph of `dist/`: no
  `@opencode-ai/*` import may be reachable statically, `plugin.js` must only
  be reached through a dynamic `import()`, and every other bare import must
  be `@opencode/plugin`, a Node builtin, or a declared runtime dependency.

## [0.4.0] - 2026-10-14

### Added

- Signed pairing offers close the pending-token rebind window (Closes #30).
  Each node keeps an Ed25519 keypair in `node.json` (generated on first run or
  on migration; the `node_id` is preserved). Pairing offers carry the emitter's
  public key (`pk`), completing a pairing pins it, mDNS TXT advertises it, and
  every outgoing mail carries a pairing proof (`<pk>.<signature>` over
  `opencode-mesh-pair:<node_id>:<token>`). A pending token now binds (or
  rotates) a peer row only with a valid proof from the pinned key: a leaked
  offer alone can no longer take over a paired peer's credential. Peers paired
  without a pinned key (0.3.0-era rows, or completions without `pk`) refuse
  remote rebinding: re-run `mesh_pair` to rotate them. `peers` gains a
  `public_key` column (schema version 2, migrated in place).

### Fixed

- Peer addresses in the IPv4-mapped IPv6 form (`[::ffff:192.168.1.10]:4399`)
  are accepted, so a dual-stack resolver's reported address no longer leaves
  its peer unreachable ("no known address with a port"). Portless and
  empty-zone forms stay rejected.

## [0.3.0] - 2026-10-14

### Added

- Documentation: `docs/CONFIGURATION.md` (the full options reference), and new
  architecture and wire protocol docs detailing the process model, worker
  lifecycle, data-dir layout, and the HTTP/mDNS/pairing protocol. The README
  links them and documents the plugin options inline.
- Plugin options are validated at setup. A `port` outside `[0, 65535]` or not an
  integer, a `bind` other than `loopback`/`lan`, a non-boolean `advertise`, or an
  empty/non-string `dataDir` now fails fast with a clear message instead of
  surfacing later as `EADDRINUSE`, a bind on the wrong interface, or a data dir
  at the wrong path. `tsconfig.test.json` and a `pnpm typecheck:tests` step
  typecheck the test suite, which `tsconfig.json` (src only) never did.

### Changed

- `engines.node` is now `>=22.5.0` (the first release with `node:sqlite`), and
  `@types/node` is pinned to the max Node major tested in CI (24) instead of 26.
  `scripts/smoke-dist.mjs` now asserts the v2 (`setup`) entrypoint, and
  `biome.json` is migrated to the 2.5.x schema.
- `mesh_lock` is documented and advertised as local to this machine: it is
  enforced between sessions sharing this host's data directory and is not part
  of the wire protocol. A guard test fails the build if a lock route reappears
  on the server.
- Removed the Ed25519 keypair ceremony in node identity: nothing signed or
  verified with it, so the short fingerprint is derived from `node_id`.
  Existing node ids are preserved on upgrade; the fingerprint value changes,
  which may require re-pairing peers.
- Workers spawned by `mesh_spawn` run with `OPENCODE_MESH_CHILD=1` and skip the
  server, mDNS and all mesh tools, so a pool of N workers no longer costs N
  mesh nodes.
- `mesh_worker_logs` reads only the tail of a worker log instead of loading the
  whole file on the host's event loop; `mesh_status` caches `tailscale status`
  for 60s and bounds the subprocess with a 2s timeout.

### Fixed

- The docs no longer claim security behaviour the code does not implement:
  `SECURITY.md` drops the "refuses entries that look like API-key formats"
  promise (no such filtering exists) and the umask-077 claim (the data
  *directory* is created `0700`; the SQLite file itself is not `chmod`ed), and
  the README drops the non-existent `"allow_tailnet"` option while updating its
  stale install pin.
- `mesh_pair` now rejects an empty `node_id` or `token` instead of completing a
  pairing with a credential nobody can present (or that clobbers a peer record).
  A partially-supplied pair (`node_id` without `token`, or vice versa) is an
  error rather than being silently ignored.
- The mesh server reports a body read failure as `400` (malformed request) rather
  than `413` (too large): a client that drops the connection mid-body no longer
  looks like an oversized payload.
- Peer addresses that carry an IPv6 zone id (`[fe80::1%eth0]:4399`) are accepted,
  so a link-local peer is no longer silently unreachable.
- `defaultDataDir()` no longer resolves to a filesystem-root path
  (`/.local/share/opencode-mesh`) when `HOME` is unset or blank: it falls back to
  `os.homedir()`, then `os.tmpdir()`.
- The node identity migration now finishes on disk: a `node.json` written by
  <= 0.2.0 is rewritten without its dead Ed25519 keypair, so the stale key
  material no longer lingers after the id is loaded. A corrupt or `node_id`-less
  `node.json` now fails loudly with a recovery path instead of silently minting a
  new node id, which would break every peer that recognised the node. Closes #31.
- `mesh_lock` no longer throws a raw `UNIQUE constraint failed` error when two
  opencode sessions sharing the same data directory race for the same path. The
  lock claim is a single atomic `INSERT ... ON CONFLICT DO NOTHING`, and the
  worker status transition is a single guarded `UPDATE`, so a stale
  read-then-write can neither raise nor overwrite a concurrently finalized row.
- The mesh database now records a schema version (`PRAGMA user_version`) and
  creates indexes for its hot lookups (unread messages, pending pairing tokens,
  peer tokens, running workers, expired locks).
- On OpenCode 2.x hosts, `mesh_spawn` and `mesh_worker_remove` no longer hand the
  raw `ctx.worktree` domain to the REST-shaped worktree client. The in-process
  domain (which resolves payloads directly, without the v1 `{ data, error }`
  envelope) is wrapped back into that shape, and an injected
  `options.worktreeClient` now takes precedence. Closes #29.
- Worktree create/remove calls on the 1.x REST client are bounded by a 15s
  timeout. A create response with no directory, or a remove response that is
  not a boolean, now raises a clear error instead of persisting an `undefined`
  directory. When the 2.x domain reports only a directory (no branch), the
  worker's branch falls back to that directory's name.
- A spawn that fails before the child runs no longer leaks its worktree:
  `mesh_spawn` removes the worktree and the dead registry row when the child
  never starts or `runWorker` throws. `mesh_worker_remove` keeps the registry
  row when the worktree was not actually removed, instead of orphaning it.
- Node runtime support: the published package no longer calls `require()` from
  ESM modules. The Node fallback paths (`node:sqlite` engine, `node:crypto`)
  now use static and dynamic imports and actually run. Vitest's module runner
  injects a `require`, which hid the `ReferenceError` from the suite, so
  `scripts/smoke-dist.mjs` loads the built package under plain Node and is part
  of `pnpm verify`.
- `mesh_send` no longer derives the peer's port from the local node. Discovered
  addresses now carry the port from the mDNS SRV record (`[ipv6]:port` for IPv6
  literals), and a portless address is refused instead of resolving to a wrong
  socket. Peers that fall back to an ephemeral port are now reachable.
- Workers killed through `mesh_worker_stop` no longer orphan their own child
  processes: workers are detached process-group leaders and a stop takes the
  group down. The late `exit` event after a deliberate stop no longer throws;
  a host restart reconciles `running` rows whose pid is gone.
- A worker that fails to start (binary missing, `error` event with no `exit`)
  is now finalized as `failed` instead of staying `running` forever with a
  leaked live entry; a `-1` pid is never persisted. `mesh_spawn` reports the
  failure instead of a success envelope.
- A worker's stderr is drained into its log; a child writing more than the pipe
  buffer (~64 KB) to stderr no longer blocks. `mesh_worker_stop` escalates
  `SIGTERM` to `SIGKILL` after 3s so a worker ignoring the signal cannot linger.
- Worker logs are capped at 512 KB (rotated to `<id>.log.1`) and deleted by
  `mesh_worker_remove`, so a chatty worker cannot fill the disk.
- A JSON line split across two stdout chunks is now reassembled before parsing,
  so a worker's `session_id` is captured instead of silently dropping to null.
  A session id arriving after the row is terminal is ignored.

### Security

- The mesh HTTP server binds to `127.0.0.1` by default. `"bind": "lan"` opts
  into listening on all interfaces, and `mesh_status` / the `mesh_pair` offer
  report the address actually bound instead of a hardcoded loopback string.
- Pairing offers expire after 5 minutes, are pruned on check, and a pending
  token alone no longer installs a permanent peer: the claimed node must
  already be known to this host (mDNS discovery or explicit `mesh_pair`).
  Auto-pairing a previously unknown node id is gone.
- Discovered peers keep their hostname and fingerprint through pairing instead
  of collapsing to `"pending"`, so `mesh_status` still shows a real identity.

### Removed

- `/announce` endpoint, its parser and `touchAddress` (no client ever called
  the route).

## [0.2.0] - 2026-10-12

### Added

- Dual-export plugin entry for OpenCode 2: one published package runs on both
  OpenCode 1.18 and 2.x (official migration pattern, "Support V1 and V2 from
  one package"). v1 hosts call `server()` (unchanged); v2 hosts call `setup()`
  (`Plugin.define`). Both entries drive the same engine.

## [0.1.2] - 2026-09-23

### Changed

- Install docs describe opencode auto-install into its plugin cache; global npm/pnpm/mise installs are not used for plugin loading.
- `mesh_status` now reports active locks, matching what `mesh_lock` errors have always told the model to check.

### Removed

- Over-engineering audit cuts: test-only `pairPeer` helper (tests pair via `pairWithToken`), constant `MailMessage` fields (`to`/`session_id` were constants absent from the schema), `onSpawned` hook (never set), `rememberPeer` one-line delegate (folded into `upsertDiscoveredPeer`), dead `BunSqliteModule` interface, internal-only exports unexported (`defaultKill`), duplicated row types reused via `Omit`, `V1PluginModule` alias inlined.

## [0.1.1] - 2026-09-23

### Changed

- No functional changes: first release shipped through the tag-driven trusted-publishing pipeline (GitHub Actions OIDC, npm provenance attestation).

## [0.1.0] - 2026-09-18

### Changed

- Dev deps: vitest 5 with @vitest/coverage-v8 5 (coverage gate unchanged: 90/80).
- Trunk-based workflow: `main` is the only branch (PRs required, protected by rulesets); `dev` removed.

### Added

- Orchestrator: `mesh_spawn` runs tasks as tracked headless workers in isolated opencode worktrees (native worktree API), with `mesh_workers`, `mesh_worker_logs`, `mesh_worker_stop`, and `mesh_worker_remove`; plugin dispose SIGTERMs live workers.
- Coverage gate in CI: 90% lines/functions, 80% branches (`pnpm test:coverage` locally).
- Dependabot group coupling vitest with @vitest/* (coverage provider) so major bumps arrive together.
- CONTRIBUTING.md documents the mandatory test-first flow and the solo-maintainer merge preference.
- CONTRIBUTING.md documents the Dependabot dependency PR routine (criteria, maintainer approval, workflow-file merge options).
- Project scaffold: Apache-2.0 license, CI (biome + typecheck + vitest + gitleaks, Node 22/24 matrix), npm publish via trusted publishing, issue and PR templates, Dependabot, lefthook pre-commit.

### Fixed

- Install docs register the scoped plugin name in `opencode.json` (an unscoped spec would attempt to install a nonexistent npm package).
- Removed a stray committed PR body file (`.pr-body.md`).
- Runtime compatibility with the installed OpenCode binary: ephemeral-port fallback for mesh servers, in-process fetch reuse for the worktree API in `opencode run` mode, `bun:sqlite` module resolution for hot-loaded plugins, and workers defaulting to `--agent build`.
- CI gitleaks job no longer fails on Dependabot pull requests (push-only).
